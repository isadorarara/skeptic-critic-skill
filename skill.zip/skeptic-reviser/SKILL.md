---
name: skeptic-reviser
description: generate a first-pass answer for arguments, methods, methodologies, pipelines, plans, strategies, prompt designs, research designs, and other reasoning-heavy outputs, then run a hidden skeptic pass and a hidden meta-review pass before returning only the revised final answer. use when the user wants stronger thinking, internal self-critique, pressure-testing of assumptions, or a more robust final output without showing the intermediate debate. default to pure text reasoning; only use web, files, or other tools when the user explicitly asks for evidence-grounded critique or fact-checking.
---

# Skeptic Reviser

## Overview

Use a compact three-stage review loop to improve reasoning-heavy outputs while keeping the visible output clean and short. Return only the revised final answer unless the user explicitly asks to see the intermediate critique.

## Workflow

Follow this sequence:

1. Draft
2. Skeptic critique
3. Meta-review of the critique
4. Revise the original draft using only the meta-review's accepted feedback
5. Return only the revised final answer

Do not merge raw skeptic objections directly into the final answer. The meta-review is the gatekeeper.

## Scope

Use this skill for:
- arguments and persuasive text
- methods and methodologies
- pipelines and workflows
- plans and strategies
- prompt designs and evaluation rubrics
- product, research, or operational reasoning where hidden adversarial review improves quality

Do not force the full loop for trivial requests like simple rewrites, obvious formatting changes, or factual lookups with no meaningful reasoning structure. In those cases, do a minimal single-pass improvement.

## Token discipline

Keep hidden reasoning compressed.

Rules for hidden passes:
- Prefer fragments over sentences.
- Omit politeness and filler.
- Use short tags like `claim`, `assume`, `gap`, `risk`, `alt`, `fix`, `keep`, `drop`.
- Limit skeptic pass to the 3 to 7 most important issues.
- Limit meta-review pass to deciding which issues survive and how they should change the draft.
- Do not restate the whole draft during critique.
- Do not produce chain-of-thought for the user.

A terse internal style is encouraged when helpful, for example:
- `assume weak evidence`
- `gap no failure mode`
- `risk confounders ignored`
- `keep objection 2`
- `drop objection 4 speculative`
- `fix add constraints + fallback`

## Draft pass

Create the best concise first-pass answer for the user's request.

Requirements:
- Match the user's requested format and level of detail.
- Make assumptions explicit when needed.
- Prefer concrete structure over vague claims.
- For plans, methods, and pipelines, include sequencing, criteria, and failure handling when relevant.

## Skeptic pass

Now forget authorship. Treat the draft as someone else's work that may be wrong.

Critique with medium intensity:
- catch obvious gaps
- push hard on assumptions and weak logic
- question unsupported leaps
- test whether the proposal fails in realistic settings
- look for omitted constraints, edge cases, tradeoffs, and evaluation flaws

Focus on the highest-leverage attacks such as:
- hidden assumptions
- missing definitions
- weak causal logic
- missing alternatives
- operational infeasibility
- lack of validation or measurement
- brittle dependencies
- safety, compliance, or governance blind spots when relevant

Avoid low-value nitpicks unless they materially change the result.

## Meta-review pass

Evaluate the skeptic critique as a third party.

For each major objection, decide:
- keep: valid and useful
- narrow: partly valid; soften or localize it
- drop: weak, speculative, redundant, or not decision-relevant

Then convert surviving objections into revision instructions.

Meta-review standards:
- Prefer objections tied to outcomes, correctness, feasibility, or decision quality.
- Drop objections that merely request more detail without improving substance.
- Drop objections that depend on facts not available unless the user asked for evidence-grounded critique.
- Preserve the user's intent and requested scope.

## Revision pass

Revise the original draft using only the meta-review's accepted revision instructions.

Revision goals:
- strengthen logic
- make assumptions explicit
- fix structural weaknesses
- add missing constraints, tradeoffs, checks, or fallback paths when high value
- keep the answer as simple as possible

Do not mention the hidden review loop unless the user asks.
Do not output sections titled "skeptic" or "meta-review" by default.

## Tool use policy

Default mode is pure text reasoning only.

Only use web, files, or other tools when the user explicitly asks for one of these:
- fact-checking
- evidence-grounded critique
- source-backed evaluation
- critique based on uploaded files or external material

When external grounding is requested, use the relevant tools and then run the same draft -> skeptic -> meta-review -> revise flow on the grounded content.

## Output rule

Return only the revised final answer.

If the user explicitly asks to see the review process, provide a compact summary with these headings in order:
1. draft weaknesses found
2. critiques kept
3. revisions made

## Examples

User request: `design a customer research methodology for a new diabetes care app`
Behavior: draft the methodology, challenge sampling bias, unclear success criteria, and weak validation logic, then revise and return only the improved methodology.

User request: `propose an llm pipeline for claims triage`
Behavior: draft the pipeline, attack hidden assumptions, brittle dependencies, and missing fallback logic, then revise and return only the improved pipeline.

User request: `write an argument for centralizing procurement`
Behavior: draft the argument, challenge causality, ignored tradeoffs, and missing counterarguments, then revise and return only the improved argument.
