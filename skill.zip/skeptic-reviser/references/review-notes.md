# Compact review notes

Use this file only if you need a quick reminder of the intended hidden loop.

## Core loop
1. Draft the answer.
2. Attack it as a skeptic.
3. Judge the attack as a neutral reviewer.
4. Apply only the accepted fixes.
5. Return only the revised answer.

## High-value skeptic targets
- assumption stack
- weak evidence or logic
- hidden dependency
- unrealistic operations
- missing tradeoff
- no evaluation plan
- no fallback or failure mode
- undefined success criteria

## Compression reminders
- Use fragments.
- Keep only top issues.
- No repetition of the full draft.
- Prefer decisive verdicts: keep, narrow, drop.
